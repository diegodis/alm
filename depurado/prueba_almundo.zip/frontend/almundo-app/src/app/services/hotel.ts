export interface Hotel {
  name:string,
  starts:number,
  price:number,
  image:string,
  amenities:string[]
}
